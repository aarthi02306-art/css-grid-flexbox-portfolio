// Light/dark theme toggle. Saves the choice and respects the OS setting by default.
(function () {
  var root = document.documentElement;
  var btn = document.getElementById("theme-toggle");
  if (!btn) return;

  function systemDark() {
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  }
  function apply(theme) {
    root.setAttribute("data-theme", theme);
    btn.setAttribute("aria-pressed", String(theme === "dark"));
    btn.textContent = theme === "dark" ? "Light mode" : "Dark mode";
  }

  var saved = null;
  try { saved = localStorage.getItem("theme"); } catch (e) {}
  apply(saved || (systemDark() ? "dark" : "light"));

  btn.addEventListener("click", function () {
    var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    apply(next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });
})();
